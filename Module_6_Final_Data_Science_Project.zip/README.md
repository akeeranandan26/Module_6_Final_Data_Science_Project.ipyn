# Student Performance Analysis & Prediction

## Module 6 – Final Data Science Project

This project demonstrates an end-to-end Data Science workflow using Python and Machine Learning.

### Objective
Analyze factors related to exam performance and build a model that predicts a student's exam score.

### Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Google Colab / Jupyter Notebook
- GitHub

### Models
1. Linear Regression
2. Random Forest Regression

### Workflow
Data → Cleaning/Inspection → EDA → Visualization → Train/Test Split → ML Models → Evaluation → Prediction

### Dataset
The notebook generates a reproducible demo dataset with 1,000 synthetic student records. It is clearly labeled as synthetic and should not be represented as real institutional student data.

### Features
- Study hours
- Attendance
- Assignments completed
- Previous score
- Sleep hours
- Internet access
- Extracurricular participation

### Target
- Exam score

### Evaluation metrics
- MAE
- RMSE
- R² score

### Files
- `Module_6_Final_Data_Science_Project.ipynb` – complete project notebook
- `README.md` – project documentation
- `requirements.txt` – Python dependencies

### How to run
1. Upload the `.ipynb` file to Google Colab.
2. Run all cells from top to bottom.
3. Review the graphs, metrics and feature importance.
4. Download the completed notebook.
5. Upload the notebook and README to GitHub.

### Portfolio description
Built an end-to-end student performance prediction project using Python, exploratory data analysis and machine learning. Compared Linear Regression and Random Forest Regression using MAE, RMSE and R², and visualized relationships between academic factors and predicted exam performance.

## Important note
This is an educational portfolio project using synthetic data. It does not make claims about real students or any specific institution.
